# -*- coding: utf-8 -*-
#生产环境配置文件
from config.base_setting import *
DEBUG = False