# -*- coding: utf-8 -*-

class JobTask():
    def __init__(self):
        pass

    def run(self,params):
        print( "Job测试打印" )
        print( params )